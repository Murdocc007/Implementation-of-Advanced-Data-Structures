For level 1, use the same test inputs as sp0pq.
